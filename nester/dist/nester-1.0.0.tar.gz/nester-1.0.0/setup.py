from distutils.core import setup

setup(
    name         = 'nester',
    version      = '1.0.0',
    py_models    = ['nester'], #將模組中的中介資料關聯到setup
    auther       = 'Ashlet',
    auther_email = 'kna8421@gmail.com',
    url          = '',
    description  = 'a simple printer of nested list'
)